import Component4 from "./Component4";

var Component3 = () =>{
    return(
        <div>
            <h1>In Component 3</h1>
            <Component4 />
        </div>
    )
}
export default Component3;