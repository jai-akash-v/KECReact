//Component 1 is your UseContext.jsx
import Component3 from "./Component3";

var Component2 = () =>{
    return(
        <section>
            <h1>In Component 2</h1>
            <Component3 />
        </section>
    )
}
export default Component2;