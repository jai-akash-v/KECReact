import StudentResults from "./StudentResults";

var Component4 = () =>{
    return(
        <div>
            <h1>In Component 4</h1>
            <StudentResults />
        </div>
    )
}
export default Component4;