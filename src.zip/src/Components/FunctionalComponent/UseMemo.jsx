var UseMemo = () =>{
    return(
        <section>
            <h1>This is UseMemo Example</h1>
        </section>
    )
}
export default UseMemo;