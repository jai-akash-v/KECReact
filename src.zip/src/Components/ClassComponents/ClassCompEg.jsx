import React from "react";
class ClassCompEg extends React.Component{
    render(){
        return (
            <div>
                <h1>This is a class component example</h1>
            </div>
        )
    }
}
export default ClassCompEg; 